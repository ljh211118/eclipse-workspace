
public class Test {

	public static void main(String[] args) {
		
		// 성인 수
		int adultCount = 1;
		
		// 어린이 수
		int childCount = 2;
 
		// 입장료 계산하기
		
		// 성인 1인당 요금
		int adultFee = 20000;
		
		// 어린이 1인당 요금
		int childFee = 9900;
		
		// 입장료 계산 (int - double로 들어가서 에러 표시 안남)
		int fee = (adultCount * adultFee) + (childCount * childFee);
		
		
		// 입장료(원래 49900원에서 fee로 변경/ int - double로 만들기)
				double totalFee = fee; 
		
		// 단체 할인
		
		// 할인률
		double discount = 0.2;
		
		//전체 사람 수 계산하기
		int totalCount = adultCount + childCount;
		if (totalCount >= 5) {  //5명 이상이라면 
		    totalFee = fee - (fee * discount);
		}
		
		// 입장료 계산 끝
		
		
		
		// 화면에 출력
		System.out.println("성인 수 : " + adultCount);
		System.out.println("어린이 수 : " + childCount);
		System.out.println("계산된 요금 " + fee);
		// 할인률 반영
		System.out.println("입장료 : " + totalFee);
	}

}
