
public class Test2 {

	public static void main(String[] args) {
		
		// 성인 수
		int adultCount = 2;
		
		// 어린이 수
		int childCount = 1;
 
		// 입장료 계산하기

		
		// 성인 1인당 요금
		int adultFee = 20000;
		
		// 어린이 1인당 요금
		int childFee = 9900;
		
		//입장료 계산하는 함수상자 실행하기
		double totalFee = calculate(adultCount, childCount, adultFee, childFee);
		int totalFeeInt = (int) totalFee;
		
		// 화면에 출력
		System.out.println("성인 수 : " + adultCount);
		System.out.println("어린이 수 : " + childCount);
		// 할인률 반영
		System.out.println("입장료 : " + totalFee);
	}
	
	// 위의 adultCount랑 다름
	static double calculate(int adultCount, int childCount, int adultFee, int childFee) {
		
		int fee = (adultCount * adultFee) + (childCount * childFee);
		System.out.println("fee : " + fee);
		
		// 입장료(원래 49900원에서 fee로 변경/ int - double로 만들기)
		double totalFee = fee; 

        // 단체 할인

        //전체 사람 수 계산하기
       int totalCount = adultCount + childCount;
       if (totalCount >= 5) {  //5명 이상이라면 
           totalFee = discount(fee);
	}
       return totalFee;
	}
	
	static int discount(int fee) {
        // 할인률
        double discount = 0.2;
        int result = (int) (fee - (fee * discount));
        return result;
	}
	
}	


