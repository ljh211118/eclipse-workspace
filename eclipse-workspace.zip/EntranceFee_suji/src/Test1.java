
public class Test1 {

	public static void main(String[] args) {
		
		int adultCount = 3;
		int childCount = 2;
		int adultFee = 20000;
		int childFee = 9900;
		
		//입장료 계산하는 함수상자 실행하기
		double totalFee = calculate(adultCount, childCount, adultFee, childFee);
		int totalFeeInt= (int) totalFee;
		
		
		System.out.println("성인 수 : " + adultCount);
		System.out.println("어린이 수 : " + childCount);
		System.out.println("입장료 : " + totalFee);
	}
	
	static double calculate(int adultCount, int childCount, int adultFee, int childFee) {
	
	  int fee = (adultCount * adultFee) + (childCount * childFee);
	  System.out.println("fee : " + fee);

	  double totalFee = fee;
	
	  double discount = 0.2;
	
	  int totalCount = adultCount + childCount;
	  if (totalCount >= 5) {
		 totalFee = fee - (fee * discount);
	}
	  return totalFee;
	  
	}
	
}
	

	
