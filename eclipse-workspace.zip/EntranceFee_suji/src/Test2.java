
public class Test2 {

	public static void main(String[] args) {
		
		int adultCount = 5;
		int childCount = 1;
		int adultFee = 20000;
		int childFee = 9900;
		double discount = 0.2;
		double countdis = 0;
		
		int people = pdd (adultCount, childCount);
		
		
		int fee = adultFee*adultCount + childFee*childCount;
		
		if(people >= 5) {
			 countdis = (double)fee*(1-discount);
			
		}
		else
		{
			countdis = fee;
		}
		
		System.out.println("사람 수 : " + people + "명");
		System.out.println("총요금 : " + fee + "원");
		System.out.println("할인된 요금 : " + countdis + "원");
       

	}
	
	    static int pdd (int adultCount, int childCount) {
	    	
	    	int sum = adultCount + childCount;
	    	
	    	return sum;  
	    	
	    }
	    int add (int adultFee, int adultCOunt, int childFee, int childCount) {
	    	
	    	return sum;
	    }
	    

}
