
public class Test {

	public static void main(String[] args) {
		
		System.out.println("안녕하세요.");

		// 변수상자 만들기
		String name;
		name = "안녕";
		
		int age;
		age =21;
		
		System.out.println("이름 : " + name + ", 나이 : " + age );
		
		// 변수상자 만들면서 초기화하기
		String name2 = "홍길동";
		int age2 = 22;
		
		System.out.println("이름 : " + name2 + ", 나이 : " + age2);
		
		// 함수 실행하기
		 print();
		 
		 walk(8);
		 
		 int result = add(10, 10);
		 System.out.println("더하기 결과 : " + result);
	}
	
	static void print() {
		System.out.println("print 함수 실행됨.");
	}

	static void walk(int speed) {
		System.out.println("사람이 " + speed + "km 속도로 걸어갑니다.");
	}
	
	static int add(int a, int b) {
		return a + b;
	}
}


