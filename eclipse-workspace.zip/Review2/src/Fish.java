
public class Fish {

	String name;
	int age;
	
	//생성자 함수 (실제 붕어빵을 만들 때 실행됨)
	Fish(String name, int age) {
		System.out.println("Fish의 생성자 함수 호출됨.");
		
		this.name = name;
		this.age = age;
		
	}
}
