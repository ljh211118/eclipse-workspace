
public class Sea {

	String name = "태평양";
	
	Fish fish;
	
	
	
}
