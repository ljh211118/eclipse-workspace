
public class Test {

	public static void main(String[] args) {
		
		// 변수상자 만들기
		String name;
		int age;
		
		// 변수상자에 값 넣기 (할당)
		name = "홍길동";
		age = 10;
		
		System.out.println("이름 : " + name + ", 나이 : " + age);

	}

}
