
public class Test2 {

	public static void main(String[] args) {
		
		// 함수상자 실행하기
		int result = add(10, 10);
		System.out.println("더하기 결과 :" + result);
	

	}

	//함수 상자 만들기
	static int add(int a, int b) {
		System.out.println("add 함수 실행됨.");
		
		int result = a + b;
		return result;
	}
	
	
}
