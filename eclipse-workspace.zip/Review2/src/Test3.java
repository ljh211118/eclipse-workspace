import java.util.ArrayList;

public class Test3 {

	public static void main(String[] args) {
		
		// 클래스 만들기(붕어빵 틀=변수상자, 함수상자 모아 놓은 곳)
		// 클래스 사용하기 (붕어빵 틀에서 붕어빵 찍어내기)
		
		Fish fish1 = new Fish("붕어빵1", 1);
		//fish1.name = "붕어빵1";
		//fish1.age = 1;
		
		Fish fish2 = new Fish("붕어빵2", 2);
		//fish2.name = "붕어빵2";
		//fish2.age = 2;
		
		System.out.println("첫번째 붕어빵의 이름 : " + fish1.name + ", 나이 " + fish1.age);
			
		// 바다 안에 붕어빵 넣기
		Sea sea1 = new Sea();
		sea1.fish = fish2;
		
		System.out.println("바다 안의 물고기 이름 : " + sea1.fish.name);
		
		//하나의 변수 상자 안에 여려개의 값을 넣어두기
		//오류뜨면 import 넣어주기
		ArrayList<String> names = new ArrayList<String>();
		names.add("홍길동1");
		names.add("홍길동2");
		
		System.out.println("이름의 갯수 : " + names.size());	
		System.out.println("첫번째 이름 : " + names.get(0));
		
	}
	
}
 
