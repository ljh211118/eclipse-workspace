
public class Test1 {

	public static void main(String[] args) {
		
		// 변수상자를 만들고 값을 넣기 (초기화)
		String name = "잠만보";
		int age = 100;
		
		System.out.println("이름 : " + name);
		System.out.println("나이 : " + age);

		// 변수상자만 만들기
		String name2;
		//변수 상자를 만드는 것이 아니라 가리키는 것
		name2 = "홍길동2";
		
		// 값을 더하기
		int age1 = 10;
		int age2 = 20;
		
		int result1 = age1 + age2;
		
		System.out.println(name);
		System.out.println(result1);
		
		int age3 = 50;
		age3 = age1 + age2;
		System.out.println("age3 : " + age3);
		
	}

}
