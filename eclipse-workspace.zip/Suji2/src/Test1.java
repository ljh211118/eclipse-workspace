
public class Test1 {

	public static void main(String[] args) {
		
		String name3 = "이수지";
		int age4 = 27;
		
		System.out.println("이름 :" + name3);
		System.out.println("나이 :" + age4);

	}

}
