
public class Test1 {

	public static void main(String[] args) {
		
		String name11 = "데이식스";
		int age1 = 4;
		
		System.out.println("이름 : " + name11);
		System.out.println("나이 : " + age1);

	}

}
