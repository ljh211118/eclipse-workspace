
public class Test1 {

	public static void main(String[] args) {
		
		//add라는 이름의 함수상자를 실행해요.
		int a = 6;
		int b = 7;
		int result = add(a,b);
		System.out.println("더하기 결과 : " + result);
		
		//nanu라는 이름의 함수상자를 실행해요.
		int c = 10;
		int d = 5;
		int result2 = nanu(c,d);
		System.out.println("나누기 결과 : " + result2);
		
		//minus라는 이름의 함수상자를 실행해요.
		int e = 15;
		int f = 10;
		int result3 = minus(e,f);
		System.out.println("빼기 결과 : " + result3);
		
		//multi라는 이름의 함수상자를 실행해요.
		int g = 25;
		int h = 34;
		int result4 = multi(g,h);
		System.out.println("곱하기 결과 : " + result4);
			
	}
	
	// add라는 함수상자를 만들어요.
	static int add(int a, int b) {
		return a + b;
	}
		
	// nanu이라는 함수 상자를 만들어요.
	static int nanu(int c, int d) {
		return c/d;
	}
	// minus라는 함수상자를 만들어요.
	static int minus(int e, int f) {
		return e-f;
	}
	// multi라는 함수상자를 만들어요.
	static int multi(int g, int h) {
		return g*h;
	}
}


