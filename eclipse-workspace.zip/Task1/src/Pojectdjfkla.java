
public class Pojectdjfkla {

	public static void main(String[] args) {
		
		int ac = 1;
		int af = 20000;
		int cc = 2;
		int cf = 9900;
		
		System.out.println(totalfee(ac, af, cc, cf));

	}
	
	static double totalfee(int ac, int af, int cc, int cf) {
		
		int total = ac + cc;
		int money = af * ac + cf * cc;
		
		if (total >= 5) {
			return money * 0.8 ;
		} else {
			return money;
		}
	}

}
