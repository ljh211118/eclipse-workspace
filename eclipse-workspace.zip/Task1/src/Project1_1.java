
public class Project1_1 {

	public static void main(String[] args) {
		
		int a = 1;
		int c = 2;
		int money = result(a,c);
		System.out.println("입장료는 " + money + "입니다.");

	}
      static int result (int a, int c) {
    	 int all =  a*20000 + c*9900;
    	 
    	 if (a + c > 4) {
    		 all = all - all/5;
    	 }
    	 return all;
      }
}
