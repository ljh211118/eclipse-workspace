
public class Project1_2 {

	public static void main(String[] args) {
		
     int adultCount = 1;
     int childCount = 2;
     
     int result = totalmoney(adultCount,childCount);
     
     System.out.println("총액은 : " + result + "원");
     System.out.println("성인 : " + adultCount + "명");
     System.out.println("어린이는 :" + childCount + "명");
	}
    
	static int totalmoney(int adultCount, int childCount) {
		int adultFree = adultCount*20000;
	    int childFree = childCount*9900;
		int totalmoney=  adultFree + childFree;
	     
	     if (adultCount + childCount > 4 ) {
	    	 totalmoney = (int) (totalmoney*0.8);
	    	 
	     }
	     
	     return totalmoney; 
	}
	
}
