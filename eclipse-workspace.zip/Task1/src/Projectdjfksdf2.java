
public class Projectdjfksdf2 {

	public static void main(String[] args) {
		
		totalfee(1, 2, 20000, 9900);

	}
	
	static void totalfee(int ac, int af, int cc, int cf) {
		
		int total = ac + cc;
		int money = af * ac + cf * cc;
		
		if(total >= 5) {
			System.out.println(money*0.8);
		} else {
			
			
		}
	}

}
