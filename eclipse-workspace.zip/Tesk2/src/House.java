
public class House {

	String name;
	Person person;
	Dog dog;
	Cat cat;
	
	House(String name, Person person, Dog dog, Cat cat) {
		this.name = name;
		this.person = person;
		this.dog = dog;
		this.cat = cat;
	}
	
	
	
}
