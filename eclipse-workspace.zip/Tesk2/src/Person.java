
public class Person {

	String name;
	
	int age;
	
	String number;
	
	Person(String name, int age, String number) {
		this.name = name;
		this.age = age;
		this.number =number;
		
	}
}
