
public class Test {

	public static void main(String[] args) {
		
		Person person1 = new Person();
		person1.name = "이수지";
		person1.age = 27;
		person1.number =7375;
		
		Dog dog1 = new Dog();
		dog1.name = "행복";
		dog1.age = 18;
		dog1.number = 2791;
		
		Cat cat1 = new Cat();
		cat1.name = "구름";
		cat1.age = 3;
		cat1.number = 4934;
		
		// 집에 진짜 집 만들기
		House house1 = new House(person1, dog1, cat1);
		house1.name = "집1";
		house1.person1 = person1;
		house1.dog1 = dog1;
		house1.cat1 = cat1;
		
		
		
		
		

	}

}
