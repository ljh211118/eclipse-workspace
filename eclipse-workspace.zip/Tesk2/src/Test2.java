
public class Test2 {

	public static void main(String[] args) {
		
		Person person1 = new Person("이수지", 27, "010-7375-2791");
		Dog dog1 = new Dog("행복");
		Cat cat1 = new Cat("구름");
		
		Person person2 = new Person("유도현", 30, "010-7372-7219");
		Dog dog2 = new Dog("바다");
		Cat cat2 = new Cat("산");
		
		Person person3 = new Person("이호훈", 24, "010-3464-3287");
		Dog dog3 = new Dog("헬로우");
		Cat cat3 = new Cat("안녕");
		
		// 집에 진짜 집 만들기
		House house1 = new House("집1", person1, dog1, cat1);
		House house2 = new House("집2", person2, dog2, cat2);
		House house3 = new House("집3", person3, dog3, cat3);
		
		
		
		System.out.println(house1.name);
		System.out.println(house1.person.name + " " + house1.person.age + " " +  house1.person.number);
		System.out.println(house1.dog.name);
		System.out.println(house1.cat.name);
		
		System.out.println(house2.name);
		System.out.println(house2.person.name + " " + house2.person.age + " " + house2.person.number);
		System.out.println(house2.dog.name);
		System.out.println(house2.cat.name);
		
		System.out.println(house3.name);
		System.out.println(house3.person.name + " " + house3.person.age + " " + house3.person.number);
		System.out.println(house3.dog.name);
		System.out.println(house3.cat.name);
		
		
		
		
		

	}

}
