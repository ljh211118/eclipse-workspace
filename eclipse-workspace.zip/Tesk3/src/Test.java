import com.lx.animal.Dog;
import com.lx.house.House;

public class Test {

	public static void main(String[] args) {
		
	Dog dog1 = new Dog();
	dog1.setName("방방이");
	dog1.setAge(2);
	dog1.setNumber("010-3453-3489");
	
	Dog dog2 = new Dog();
	dog2.setName("촐랑이");
	dog2.setAge(3);
	dog2.setNumber("010-3434-2434");
	
	House house1 = new House();
	house1.setName("레미안");
	house1.setdogs(dog1);
	house1.setdogs(dog2);
	
	House house2 = new House();
	
	
	//run 함수 호출
	house1.run(house1.getdogs());
	
	System.out.println("우리집 강아지 : " + house1.getdogs().get(1).getName());

	}

}
