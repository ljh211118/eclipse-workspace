package com.lx.animal;

public class Dog {// 생성자 함수: 초기화 시켜줌 
	
	String name;// 초기화가 안된 것
	int age;
	String number;
	
	// 메소드를 통해서만 관리 , return
	public String getName() {
		return name;
	}
	
	// 출력
	public void setName(String name) {
		this.name = name;
	}
	
	public int getAge() {
		return age;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	
	public String setNumber() {
		return number;
	}
	
	public void setNumber(String number) {
		this.number = number;
	}

}
