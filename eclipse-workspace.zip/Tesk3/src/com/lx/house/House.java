package com.lx.house;

import java.util.ArrayList;

import com.lx.animal.Dog;

public class House {

	String name;
	
	// 함수: 데이터를 받아와서 연산 처리
	// 함수 만들기, 개 유무
	public void run(ArrayList<Dog> dogs) {
		if (dogs.size()==0) {
			System.out.println("개가 없습니다.");
		}
		else {
			for(int i = 0; i < dogs.size(); i++) {
				System.out.println(dogs.get(i).getName());
			}
		}
	}
	
	ArrayList<Dog> dogs = new ArrayList<>();
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public ArrayList<Dog> getdogs() {
		return dogs;
		
	}
	
	public void setdogs(Dog dogs) {
		this.dogs.add(dogs);
	}
		


	

}
