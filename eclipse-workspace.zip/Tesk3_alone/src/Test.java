import com.lx.animal.Dog;
import com.lx.house.House;

public class Test {

	public static void main(String[] args) {
		
		Dog dog1 = new Dog();
		dog1.setName("방방이");
		dog1.setAge(1);
		dog1.setNum("010-7378-3942");

		Dog dog2 = new Dog();
		dog2.setName("랄랄");
		dog2.setAge(9);
		dog2.setNum("010-2342-2493");
		
		House house1 = new House();
		house1.setName("유니시티");
		house1.setdogs(dog1);
		
		House house2 = new House();
		house2.setName("리마크빌");
	    house2.setdogs(dog2);
	    
	  
	    System.out.println("강아지 1: " + house1.getdogs().get(0).getName());
	    System.out.println("강아지 2 :" + house2.getdogs().get(0).getName());
		
	
		

	}

}
