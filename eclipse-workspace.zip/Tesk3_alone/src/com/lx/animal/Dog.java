package com.lx.animal;

public class Dog {

	String name;
	int age;
	String num;
	
	public void setName(String name) {
		this.name = name;
	}
	public String getName(){
		return name;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getAge() {
		return age;
	}
	public void setNum(String num) {
		this.num = num;
	}
	public String getNum() {
		return num;
	}
	
}
