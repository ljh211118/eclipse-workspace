
// 부모 클래스
public class Animal {
	
	
	//변수상자
	String name;
	int age;
	String num;
	
	static int count = 0;

	
	//생성자 함수
	Animal(){
		count++;
	}
	//함수상자
	void run() {
		System.out.println("동물이 달립니다.");
	}
	void standup() {
		System.out.println("동물이 서있습니다.");
	}
	void sitdown() {
		System.out.println("동물이 앉아있습니다.");
	}

}
