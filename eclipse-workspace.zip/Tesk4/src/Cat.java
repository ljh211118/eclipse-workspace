//자식 클래스
public class Cat extends Animal {

	static int count = 0;
	Cat(){
		count++;
	}
	
	void standup() {
		System.out.println("고양이가 서있다.");
	}
	void sitdown() {
		System.out.println("고양이가 앉아있다.");
	}
	void run() {
		System.out.println("고양이가 달립니다.");
	}
}
