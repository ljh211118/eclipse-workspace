//자식 클래스
public class Dog extends Animal {

	static int count = 0;
	Dog(){
		count++;
	}
	void run() {
		System.out.println("강아지가 달립니다.");
	}
	void sitdown() {
		System.out.println("강아지 앉아!");
	}
	void standup() {
		System.out.println("강아지 일어나!");
	}
}

