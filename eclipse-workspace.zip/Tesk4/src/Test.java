
public class Test {

	public static void main(String[] args) {
		
		
		//Animal animal1 = new Animal();
		//animal1.name = "동물나라";
		
		Animal cat1 = new Cat();
		cat1.name = "냥펀치";
		cat1.age = 4;
		cat1.num = "010-3424-2423";
		
		cat1.run();
		cat1.standup();
		cat1.sitdown();
		
		System.out.println("고양이는 몇마리 인가요? "+ Animal.count);
		
		
		Animal dog1 = new Dog();
		dog1.name = "멍멍이";
		dog1.age = 8;
		dog1.num = "010-6954-4834";
		
		dog1.run();
		dog1.standup();
		dog1.sitdown();
		
	
	}

}
