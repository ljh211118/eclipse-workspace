
public class Animal {
	String name;
	int age;
	String number;
	
	static int count = 0;
	
	Animal() {
		count++;
		
	}
	
	void standup() {
		System.out.println("동물이 서있습니다");
	}
	void sitdown() {
		System.out.println("동물이 앉아있습니다");
	}
	void run() {
		System.out.println("동물이 뛰고있습니다");
	}

}
