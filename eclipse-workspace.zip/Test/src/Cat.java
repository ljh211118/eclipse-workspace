
public class Cat extends Animal {
	
	static int count = 0;
	
	Cat() {
		count++;

	}
	
	void standup() {
		System.out.println("고양이가 서있습니다");
	}
	void sitdown() {
		System.out.println("고양이가 앉아있습니다");
	}
	void run() {
		System.out.println("고양이가 뛰고있습니다");
	}

}
