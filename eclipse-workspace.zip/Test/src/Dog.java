
public class Dog extends Animal {
	
	static int count = 0;
	
	Dog() {
		count++;
		
	}
	
	void standup() {
		System.out.println("강아지가 서있습니다");
	}
	void sitdown() {
		System.out.println("강아지가 앉아있습니다");
	}
	void run() {
		System.out.println("강아지가 뛰고있습니다");
	}

}
