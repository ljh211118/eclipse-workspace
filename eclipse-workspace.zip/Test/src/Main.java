
public class Main {
	public static void main(String[] args) {
		
		Cat cat1 = new Cat();
		
		
		Cat cat2 = new Cat();
		
		System.out.println(cat2.count);
		
		Dog dog1 = new Dog();
		
		Dog dog2 = new Dog();
		
		System.out.println(Dog.count);
		
		System.out.println(Animal.count);

		
		

	}

}
