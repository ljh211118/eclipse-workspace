
	// 부모 클래스
public class Fish {

	// Fish 라는 이름의 붕어빵 틀에 붙어있는 진자 변수상자 - new
	// Static: 붕어빵 틀에 붙어있는 진짜 함수,  자식이 언제든지 사용가능
	// 초기화
	static int count = 0;
	
	// 변수상자
	String name;
	int age;
	
	// 생성자 함수 - Fish.count 말고 count만 사용해도 된다. 
	Fish() {
		Fish.count = count + 1;
	}
	
	// 함수상자
	void swim() {
		System.out.println("붕어빵이 헤엄칩니다.");
	}
}
