
// 'Fish'라는 붕어빵 틀이 있으면 그대로 가져오겠다!
// 부모 = Fish, 자식 = Shark
// extend 상속 받았다!

public class Shark extends Fish {

	// 함수상자 덮어쓰기 (재정의 : override) 
	// 부모로부터 받은 함수상자 그대로 내가 쓰겠다!
	// set 함수에서만 void 사용 - 구멍 x 동작만 시켜줌, 출력 x  - return(반환)
	void swim() {
		System.out.println("상어빵이 헤엄칩니다.");
	}
	
	void run() {
		System.out.println("상어빵이 달려갑니다.");
	}
	
}
