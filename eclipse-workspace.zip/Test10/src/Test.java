
public class Test {

	public static void main(String[] args) {
		
	//int count = 0;
	
		
	Fish fish1 = new Fish();
	fish1.name = "붕어빵1";
	
	//Fish.count = Fish.count + 1;
	
	
	Shark shark1 = new Shark();
	shark1.name = "상어빵1";
	
	//Fish.count = Fish.count + 1;
	
	System.out.println("상어빵의 이름 : " + shark1.name);
	System.out.println("몇 마리? : " + Fish.count);
	
	fish1.swim();
	shark1.swim();
	shark1.run();
	
	// 에러 X 
	Fish shark2 = new Shark();
	shark2.name = "상어빵2";
	
	//오른쪽 먼저 계산되고 왼쪽에 대입
	//Fish.count = Fish.count + 1;
	
	
	// 에러 O , 붕어빵에는 'run' 이라는 함수 X , 실제는 상어빵임에도 붕어빵으로 인식해 상어빵이 될 수 X
	//shark2.run();
	
	//(Shark) 형변환- 상속했을 때 가능
 	Shark shark3 = (Shark) shark2; 
	shark3.run();
	
	//Fish.count = Fish.count + 1;
	
	System.out.println("몇 마리? : " + Fish.count);
	
	// 클래스 함수
	double temp = 36.5;
	double temp2 = Math.floor(temp);
	System.out.println("원래값 : " + temp + "바뀐값 : " + temp2);
	
	}

}
