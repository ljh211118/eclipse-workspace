
public class Test1 {

	public static void main(String[] args) {
		
		// 변수상자
		String name = "홍길동1";
        System.out.println("이름 : " + name);
        
		String name2;
		int age1;
		
		name2 = "홍길동2";
		age1 = 21;
        
	}

}
