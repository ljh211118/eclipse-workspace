
public class Test1 {

	public static void main(String[] args) {
		
		// print1이라는 이름의 함수상자를 실행해요.
		print1();
		print1();
 
		// walk라는 이름의 함수상자를 실행해요.
		walk(8);
		
		// add라는 이름의 함수상자를 실행해요.
		int a = 10;
		int b = 10;
		int result = add(a,b);
		System.out.println("더하기 결과 : " + result);
		
	}
	
    // 바깥에 함수 상자 만들기
	// 위쪽 구멍 없음, 
	// 메인 함수에 static이 붙어 있으므로 붙여줌
	// print1이라는 이름의 함수상자를 만들어요.
	// println =  함수상자
	static void print1() {
	    System.out.println("print1 함수가 실행되었어요.");
	}
	  // void: 반환값 x
	static void walk(int speed) {
		System.out.println("사람이 " + speed + "km 속도로 걸어갑니다.");
	}
	//바로 아래쪽으로 값을 내려도 된다.
	static int add(int a, int b) {
		return a +b;
	}
} 
