
public class Fish {

	String name;
	
	int age;

}
