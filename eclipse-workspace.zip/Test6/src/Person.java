
public class Person {

	String name;
	
	int age;
	
	void walk(int speed){
		System.out.println("사람이 " + speed + "km 속도로 걸어갑니다.");
	}
	
	//실행 안되는 예
	Person() {
		
	}
	
	
	Person(String name, int age) {
		// 오른쪽에 있는 값을 왼쪽 변수상자에 넣어준다.
		// 오른쪽 name = string name, this = 붕어빵 자신, 
		this.name = name;
		this.age = age;
	}
}
