
public class Test {

	public static void main(String[] args) {
		
		String name = "홍길동1";
		int age = 21;
		
		System.out.println("이름 : " + name + ", 나이 : " + age);
		
		// 붕어빵 틀에서 붕어빵 찍어내기 / 함수 상자라기보다는 함수 상자를 실행하기는 함
		// 변수상자 이름 그대로 변수상자 크기로 지정
		Fish fish1 = new Fish();
		// System.out.oruntln 과 비슷 (name, age = 변수상자)
		fish1.name = "물고기1";
		fish1.age = 2;

		System.out.println("물고기1의 이름 : " + fish1.name + ", 나이 :" + fish1.age);
		
		// 사람을 위한 붕어빵 틀에서 사람 찍어내기
		// Person 프로젝트의 Person(String name, int age) 그대로
		Person person1 = new Person("홍길동1", 21);
		//person1.name = "홍길동1";
		//person1.age = 21;
		person1.walk(8);
	}

}
