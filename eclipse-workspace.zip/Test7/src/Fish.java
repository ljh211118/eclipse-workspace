
public class Fish {

	String name;
	
	int age;
	
	Fish(String name, int age) {
		this.name = name;
		this.age = age;
	}
}
