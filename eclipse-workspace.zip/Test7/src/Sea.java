
public class Sea {

	String name;
	
	Fish fish1;
	
	Fish fish2;
}
