
public class Shark {

	String name;
	
}
