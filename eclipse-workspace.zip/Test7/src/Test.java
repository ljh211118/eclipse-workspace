
public class Test {

	public static void main(String[] args) {
		
		// 물고기 틀(클래스)에서 진짜 물고기(객체) 만들기
		Fish fish1= new Fish("고기1", 1);
		//fish1.name = "고기1";
		
		Fish fish2 = new Fish("고기2", 2);
		//fish2.name = "고기2";
		
		// 바다 틀에서 진짜 바다 만들기
		Sea sea1 = new Sea();
		sea1.name = "태평양";
		sea1.fish1 = fish1;
		sea1.fish2 = fish2;
		
		System.out.println("바다 안에 사는 물고기 1 : " + sea1.fish1.name + "물고기 2 : " + sea1.fish2.name);
		
	}
	

}
