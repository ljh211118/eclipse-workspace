
public class Cat {

	String name;
}
