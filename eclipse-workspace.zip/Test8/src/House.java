
public class House {

	// 변수 상자
	String name;
	
	Person person;
	
	Dog dog;
	
	House() {
		
	}
	
	
	House(String name) {
		this.name = name;
		
		
	}
	
	// 생성자 함수 : 이 붕어빵 틀에서 진짜 붕어빵이 만들어질 때 그 안에 들어있는 변수상자에 값을 넣어주기 위한 것 
	//= 붕어빵 틀과 똑같이 만들어 준다.
	House(String name, Person person) {
		// 진짜를 넣어주는 것
		this.name = name;
		this.person = person;

		
	}
	House(String name, Person person, Dog dog) {
		this.name = name;
		this.person = person;
		this.dog = dog;
		
	}
}
