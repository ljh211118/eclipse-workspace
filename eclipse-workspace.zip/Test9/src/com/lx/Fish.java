package com.lx;

import java.util.ArrayList;

public class Fish {

	// getName 값 - name
	public String name;
	
	//import, ArrayList는 자바의 List 인터페이스를 상속받은 여러 클래스 중 하나
	public ArrayList<String> children= new ArrayList<String>();
	
	// setName 함수 상자 별도로 만들기 (변수 상자 이용할 필요 없이 함수 상자 이용), 입력
	public void setName(String name) {
		if (name.length() < 2) {
			System.out.println("붕어빵의 이름은 두 글자 이상이어야 합니다.");
			// return 뒤에까지 내려가지 않고 여기서 끝남
			return;
		}
		this.name = name;
	}
	
	// getName 함수 상자 별도로 만들기 = 값 넣기, 출력
	public String getName() {
		return name;
	}
	// 생성자 함수 만들기
	public Fish(String name) {
		this.name = name;
		
		children.add("붕어빵1");
		children.add("붕어빵2");
	}
	
	public void swim() {
		System.out.println("물고기가 헤엄칩니다.");
	}
	
}
